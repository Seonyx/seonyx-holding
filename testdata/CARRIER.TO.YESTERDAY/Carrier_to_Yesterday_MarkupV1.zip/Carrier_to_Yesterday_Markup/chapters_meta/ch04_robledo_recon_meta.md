# Chapter 04 Meta Notes - Robledo Recon

## What this file is
Keyed meta notes aligned 1:1 with the chapter text paragraphs.

## Meta entries
[[C04-7TNTBL3TAI]] Show Zoë competence; heist texture.

[[C04-ZK5ZE72NG7]] Grounded infiltration.

[[C04-MPBYGZYJPI]] Mateo as risk vector.

[[C04-SGZI6CTCZH]] Mentor warning without preachiness.

[[C04-5CJCX7V36M]] Plot mechanics.

[[C04-CSHJY3BXGN]] Character.

[[C04-BDPS7Z4MKT]] Atmosphere and tension.

[[C04-HUNHOGDK6T]] Awe turning into hubris.

[[C04-ARQOM4H3OT]] Action beat; suspense.

[[C04-WQFK2LW7L3]] POV contrast.

[[C04-4WM52THMVR]] Key event: send message.

[[C04-IGP24LBXTF]] Tension valley.

[[C04-DJ3EZB42II]] Proof moment.

[[C04-3LXA56YWER]] Emotional complexity.

[[C04-ME2XHIDPYQ]] Paranoia seed.

[[C04-NZ44OM22RA]] Antagonist introduced; stakes rise.
