# Chapter 02 Meta Notes - The Paper Nobody Cites

## What this file is
Keyed meta notes aligned 1:1 with the chapter text paragraphs.

## Meta entries
[[C02-I26G675ZW3]] Deepen premise; give Zoë agency and voice.

[[C02-L4CLRXGWDE]] Make the science feel plausible and seductive.

[[C02-ZLJQ7QNRYX]] Characterise Zoë: skepticism with humility.

[[C02-JLBMP2IHH4]] Reinforce tone and dynamic.

[[C02-KNVI3JITH6]] Move from concept to plan.

[[C02-IKGWN4XL4G]] Justify Robledo set-piece logically.

[[C02-MT4EJKAK6A]] Show Mateo’s impulsive leap.

[[C02-G6HVHDTV7Q]] Introduce ethical pressure.

[[C02-2OUAT3UPEI]] Set up escalation ladder; rationalisation.

[[C02-ZR7ZAOCXDA]] Create ticking-clock planning beat.

[[C02-H4RC3Y3HTO]] Introduce mentor figure.

[[C02-6AWO6MRJ74]] Show the hook that catches the mentor.

[[C02-Q7KDAKY4Y7]] Humour; self-awareness.

[[C02-MJBGGM7LPC]] Escalate mystery; imply loop.

[[C02-GLNQ36MWT6]] Theme: humans replace ethics with maths.

[[C02-V4EEAGXTXS]] Launch into Robledo recon.
