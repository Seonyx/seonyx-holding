# Chapter 06 Meta Notes - Proof of Yesterday

## What this file is
Keyed meta notes aligned 1:1 with the chapter text paragraphs.

## Meta entries
[[C06-NVRIS7U64I]] Codify story physics; show Zoë’s coping method.

[[C06-S7SYWW3RWX]] Escalation via competence.

[[C06-OXQ4MQNL7K]] Introduce feedback behaviour.

[[C06-3QIHTFXNUC]] History-as-quilt theme.

[[C06-D3ZE3WEETR]] Interpersonal tension.

[[C06-EM25OTTOBL]] Rationalised greed.

[[C06-OXVTM6KGZB]] Mentor conflict; ambiguity.

[[C06-Q3VWBVINBN]] Introduce human antagonist/complication.

[[C06-ENP2SUESJM]] Net tightens.

[[C06-XEK2PKIP7H]] Paranoia goes outward.

[[C06-BYSVPD726X]] Further moral slide.

[[C06-WDS7YJXQYN]] Raise stakes; consequences.

[[C06-WPDGB4XFZS]] Social pressure.

[[C06-HLQI4AHJ2C]] External threat.

[[C06-T6VXMM2EB2]] Character detail.

[[C06-EUUCBCNT2R]] Introduce intrusion.
