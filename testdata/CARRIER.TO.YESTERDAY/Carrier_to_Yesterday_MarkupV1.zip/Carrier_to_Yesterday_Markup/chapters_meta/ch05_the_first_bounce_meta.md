# Chapter 05 Meta Notes - The First Bounce

## What this file is
Keyed meta notes aligned 1:1 with the chapter text paragraphs.

## Meta entries
[[C05-KO27QRUIMY]] Lock in the premise.

[[C05-EZG6FECSAM]] Humour; exhaustion.

[[C05-CUKAQQX7F6]] Moral fork established.

[[C05-CNH76RFLAJ]] Attempt at restraint.

[[C05-56W6V5ET2W]] Introduce shifting history clearly.

[[C05-LM7O3YCXLJ]] Theme: denial.

[[C05-DUYE7N6OTL]] Greed disguised as methodology.

[[C05-REYEZKZQH4]] Small step into exploitation.

[[C05-TPMTZNCTHW]] Explicit boundary to break later.

[[C05-UHCUE6H6VO]] Temptation beat.

[[C05-LMDTRTI653]] Tactile detail; tone.

[[C05-GTLL7EA7U3]] First payoff; hook.

[[C05-4T7EV6OCB7]] Moral erosion.

[[C05-422BRHDYVU]] External pressure begins.

[[C05-BZCL5QWOO4]] Foreshadow conflict.

[[C05-KJ5VZALZHN]] Act I close; dread + momentum.
