# Chapter 05 - The First Bounce

## POV
Mateo (third-person limited)

## Setting
DSS-63 control-adjacent spaces

## Chapter purpose
- Move the plot: Mateo and Zoë validate the data: phase coherence, timing, and the impossible timestamp.
- Raise pressure: introduce a new constraint, threat, or moral fracture.
- End with a hook that forces the next chapter to exist.

## Beat map (high level)
- Beat 01: Mateo and Zoë validate the data: phase coherence, timing, and the impossible timestamp.
- Beat 02: They argue about causality until dawn, then stop because the sun is not impressed.
- Beat 03: Baeza demands they stop. Mateo promises, with the tone of a liar practicing.
- Beat 04: Zoë proposes a harmless test: tomorrow’s newspaper headline, nothing financial.
- Beat 05: The headline arrives early, and it is slightly different from the one they later see online.
- Beat 06: Zoë panics, Mateo rationalises: ‘AP changed the wording.’
- Beat 07: Mateo suggests lottery numbers as a cleaner test, because numbers don’t editorialise.
- Beat 08: Zoë pushes for a tiny stake, like a scientist who knows the rat is also herself.
- Beat 09: They set rules: one ticket, one draw, then stop.
- Beat 10: They receive the numbers a day early, and the thrill is pure and poisonous.
- Beat 11: Mateo buys the ticket. The kiosk receipt feels like fate printed on thermal paper.
- Beat 12: They win a small prize. Enough to prove it, not enough to satisfy.
- Beat 13: Mateo wants bigger. Zoë says no, then says maybe, then hates herself.
- Beat 14: Ortega begins a quiet internal investigation at Robledo.
- Beat 15: Baeza warns that ‘systems remember’. Mateo hears ‘systems can be beaten’.
- Beat 16: End: Zoë wakes from a dream where every clock runs a different direction.

## Draft Paragraphs (keyed)

[[C05-KO27QRUIMY]] Mateo and Zoë validate the data: phase coherence, timing, and the impossible timestamp.

[[C05-EZG6FECSAM]] They argue about causality until dawn, then stop because the sun is not impressed.

[[C05-CUKAQQX7F6]] Baeza demands they stop. Mateo promises, with the tone of a liar practicing.

[[C05-CNH76RFLAJ]] Zoë proposes a harmless test: tomorrow’s newspaper headline, nothing financial.

[[C05-56W6V5ET2W]] The headline arrives early, and it is slightly different from the one they later see online.

[[C05-LM7O3YCXLJ]] Zoë panics, Mateo rationalises: ‘AP changed the wording.’

[[C05-DUYE7N6OTL]] Mateo suggests lottery numbers as a cleaner test, because numbers don’t editorialise.

[[C05-REYEZKZQH4]] Zoë pushes for a tiny stake, like a scientist who knows the rat is also herself.

[[C05-TPMTZNCTHW]] They set rules: one ticket, one draw, then stop.

[[C05-UHCUE6H6VO]] They receive the numbers a day early, and the thrill is pure and poisonous.

[[C05-LMDTRTI653]] Mateo buys the ticket. The kiosk receipt feels like fate printed on thermal paper.

[[C05-GTLL7EA7U3]] They win a small prize. Enough to prove it, not enough to satisfy.

[[C05-4T7EV6OCB7]] Mateo wants bigger. Zoë says no, then says maybe, then hates herself.

[[C05-422BRHDYVU]] Ortega begins a quiet internal investigation at Robledo.

[[C05-BZCL5QWOO4]] Baeza warns that ‘systems remember’. Mateo hears ‘systems can be beaten’.

[[C05-KJ5VZALZHN]] End: Zoë wakes from a dream where every clock runs a different direction.
