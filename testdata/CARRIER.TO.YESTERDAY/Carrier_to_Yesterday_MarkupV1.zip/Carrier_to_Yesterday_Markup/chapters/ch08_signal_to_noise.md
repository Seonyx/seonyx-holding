# Chapter 08 - Signal-to-Noise

## POV
Zoë (third-person limited)

## Setting
Signal lab + paranoia begins

## Chapter purpose
- Move the plot: Zoë refuses Marina. Mateo considers replying, then does, then lies about it.
- Raise pressure: introduce a new constraint, threat, or moral fracture.
- End with a hook that forces the next chapter to exist.

## Beat map (high level)
- Beat 01: Zoë refuses Marina. Mateo considers replying, then does, then lies about it.
- Beat 02: The signal becomes noisier, full of partial phrases and corrupted timestamps.
- Beat 03: Zoë realises they are hearing multiple ‘versions’ of the same message, like reality buffering.
- Beat 04: Mateo insists it is multipath. Zoë says multipath doesn’t rewrite memories.
- Beat 05: Ortega runs a sting operation on likely access points, tightening the perimeter.
- Beat 06: Mateo pushes for a bigger play now, before the window closes.
- Beat 07: Zoë demands confession about Marina. Mateo dodges; Zoë sees the dodge and logs it mentally.
- Beat 08: Marina offers partnership: money, cover, legal muscle. The offer smells like a trap and a life raft.
- Beat 09: Zoë discovers a forum thread about ‘time-echo gambling’ that predates them.
- Beat 10: They test sending a short data packet and get it back early, but altered by a few bits.
- Beat 11: Zoë wonders if the loop edits messages to reduce paradox, like a bureaucrat redacting reality.
- Beat 12: Mateo begins to fear not failure but being replaced.
- Beat 13: Baeza reappears with a warning: Robledo is watching, and watching changes what you get.
- Beat 14: Zoë proposes a shutdown. Mateo proposes a last big win to fund disappearing.
- Beat 15: They compromise on a ‘final’ operation requiring a return to Robledo.
- Beat 16: End: the signal delivers their motto again, but with one extra word: ‘Procrastination is the thief of time, Mateo.’

## Draft Paragraphs (keyed)

[[C08-HLJD247AYQ]] Zoë refuses Marina. Mateo considers replying, then does, then lies about it.

[[C08-MO4LGHW2ED]] The signal becomes noisier, full of partial phrases and corrupted timestamps.

[[C08-LY6D72SUC2]] Zoë realises they are hearing multiple ‘versions’ of the same message, like reality buffering.

[[C08-TZ6GREYDEQ]] Mateo insists it is multipath. Zoë says multipath doesn’t rewrite memories.

[[C08-SXKDOIVYIG]] Ortega runs a sting operation on likely access points, tightening the perimeter.

[[C08-LDZD4HF7DL]] Mateo pushes for a bigger play now, before the window closes.

[[C08-AE5FQ5QUA7]] Zoë demands confession about Marina. Mateo dodges; Zoë sees the dodge and logs it mentally.

[[C08-ZBHARBQRWE]] Marina offers partnership: money, cover, legal muscle. The offer smells like a trap and a life raft.

[[C08-L2LVPWOTXU]] Zoë discovers a forum thread about ‘time-echo gambling’ that predates them.

[[C08-DMMFNNL4LD]] They test sending a short data packet and get it back early, but altered by a few bits.

[[C08-TIZWE3PYWI]] Zoë wonders if the loop edits messages to reduce paradox, like a bureaucrat redacting reality.

[[C08-EC4AHU3ADN]] Mateo begins to fear not failure but being replaced.

[[C08-YEXFZCCF2M]] Baeza reappears with a warning: Robledo is watching, and watching changes what you get.

[[C08-AK6C2OSNJW]] Zoë proposes a shutdown. Mateo proposes a last big win to fund disappearing.

[[C08-NF67GFYOUP]] They compromise on a ‘final’ operation requiring a return to Robledo.

[[C08-XG6OXWQEBR]] End: the signal delivers their motto again, but with one extra word: ‘Procrastination is the thief of time, Mateo.’
