# Chapter 01 - Static in the Seminar

## POV
Mateo (third-person limited)

## Setting
Madrid, UPM campus lab + rooftop

## Chapter purpose
- Move the plot: Open with Mateo in a half-empty seminar, noticing a slide that should not exist in a normal textbook.
- Raise pressure: introduce a new constraint, threat, or moral fracture.
- End with a hook that forces the next chapter to exist.

## Beat map (high level)
- Beat 01: Open with Mateo in a half-empty seminar, noticing a slide that should not exist in a normal textbook.
- Beat 02: The lecturer hand-waves the ‘advanced solutions’ bit and moves on. Mateo doesn’t.
- Beat 03: Mateo corners the lecturer, gets a shrug and a throwaway paper citation.
- Beat 04: In the lab, Mateo pulls dusty SDR gear from a cupboard like a magician retrieving a dead rabbit.
- Beat 05: He tests a control signal, gets noise, then one clean spike that repeats with a human rhythm.
- Beat 06: Mateo logs it, tells himself it is interference, then edits the log title to ‘ANOMALY’.
- Beat 07: He calls Zoë, the only person who enjoys ruining his certainty with maths.
- Beat 08: Zoë listens, dismisses, then asks for raw I/Q data, because skepticism has standards.
- Beat 09: They argue about whether ‘time-symmetric’ means ‘time travel’ or ‘narrative malpractice’.
- Beat 10: Mateo mentions Voyager as a distant coherent beacon. Zoë pauses for the first time.
- Beat 11: Night. Rooftop. Mateo aims a cheap dish at nothing in particular and feels ridiculous.
- Beat 12: The same spike returns, like a knock from a locked room.
- Beat 13: Zoë says one sentence that changes the genre: ‘If that phase is real, it can’t be coming from now.’
- Beat 14: Mateo laughs, too loud, and the laugh sounds like fear.
- Beat 15: They decide to replicate with better equipment, and swear not to tell anyone yet.
- Beat 16: End on the motif, scribbled on Mateo’s notebook margin: ‘Procrastination is the thief of time.’

## Draft Paragraphs (keyed)

[[C01-4E4JEXDWPR]] Open with Mateo in a half-empty seminar, noticing a slide that should not exist in a normal textbook.

[[C01-FN5MBFHZOF]] The lecturer hand-waves the ‘advanced solutions’ bit and moves on. Mateo doesn’t.

[[C01-3D6IIY5QAG]] Mateo corners the lecturer, gets a shrug and a throwaway paper citation.

[[C01-CD472XEIOR]] In the lab, Mateo pulls dusty SDR gear from a cupboard like a magician retrieving a dead rabbit.

[[C01-DZ3SGCBDKQ]] He tests a control signal, gets noise, then one clean spike that repeats with a human rhythm.

[[C01-A76F33HVGU]] Mateo logs it, tells himself it is interference, then edits the log title to ‘ANOMALY’.

[[C01-6BCJYMREEO]] He calls Zoë, the only person who enjoys ruining his certainty with maths.

[[C01-P3CJJV3SUW]] Zoë listens, dismisses, then asks for raw I/Q data, because skepticism has standards.

[[C01-FC6LWB7TJX]] They argue about whether ‘time-symmetric’ means ‘time travel’ or ‘narrative malpractice’.

[[C01-ICJJH7A4NL]] Mateo mentions Voyager as a distant coherent beacon. Zoë pauses for the first time.

[[C01-LQQ43KHU2K]] Night. Rooftop. Mateo aims a cheap dish at nothing in particular and feels ridiculous.

[[C01-UX62GAOZDY]] The same spike returns, like a knock from a locked room.

[[C01-C5TD22IQZO]] Zoë says one sentence that changes the genre: ‘If that phase is real, it can’t be coming from now.’

[[C01-WUAX2RUPPY]] Mateo laughs, too loud, and the laugh sounds like fear.

[[C01-EOGTEJ73EG]] They decide to replicate with better equipment, and swear not to tell anyone yet.

[[C01-PC3C53MT6F]] End on the motif, scribbled on Mateo’s notebook margin: ‘Procrastination is the thief of time.’
