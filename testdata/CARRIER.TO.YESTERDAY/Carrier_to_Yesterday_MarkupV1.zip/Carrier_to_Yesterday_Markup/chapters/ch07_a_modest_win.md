# Chapter 07 - A Modest Win

## POV
Mateo (third-person limited)

## Setting
Lottery kiosk + cramped apartment

## Chapter purpose
- Move the plot: Mateo celebrates like a man who thinks probability owes him a salary.
- Raise pressure: introduce a new constraint, threat, or moral fracture.
- End with a hook that forces the next chapter to exist.

## Beat map (high level)
- Beat 01: Mateo celebrates like a man who thinks probability owes him a salary.
- Beat 02: Zoë counts the win as evidence and as a stain; she cannot decide which is heavier.
- Beat 03: They attempt to limit exposure: different kiosks, different times, different disguises.
- Beat 04: Marina triangulates anyway, less by genius than by persistence.
- Beat 05: Zoë sees another history shift: a lecture video has different wording than last week.
- Beat 06: Mateo finally notices, laughs, then stops laughing.
- Beat 07: They debate stopping. Mateo argues ‘we can stop after we secure our lives’.
- Beat 08: Zoë proposes one final controlled experiment to send a warning to themselves, small and testable.
- Beat 09: Mateo agrees, but his eyes are on the jackpot amount.
- Beat 10: Ortega’s team finds a tiny irregularity in service corridor access logs.
- Beat 11: Baeza meets Zoë alone and tells her a story about accidents that look like fate.
- Beat 12: Zoë returns with a hard boundary: one final attempt, then burn it all.
- Beat 13: Mateo nods, then drafts a plan that violates the boundary in three places.
- Beat 14: They receive tomorrow’s numbers earlier than ever, and the window feels like it is widening.
- Beat 15: Zoë suspects the window widens because they are pulling harder, like stretching elastic.
- Beat 16: End: Marina sends an anonymous message: ‘Nice trick. Want to talk?’

## Draft Paragraphs (keyed)

[[C07-WMZ35OBVJK]] Mateo celebrates like a man who thinks probability owes him a salary.

[[C07-HVICDQ5XVS]] Zoë counts the win as evidence and as a stain; she cannot decide which is heavier.

[[C07-7RGLRHMOOF]] They attempt to limit exposure: different kiosks, different times, different disguises.

[[C07-PDEJXWG6EW]] Marina triangulates anyway, less by genius than by persistence.

[[C07-VLDXXJTOSH]] Zoë sees another history shift: a lecture video has different wording than last week.

[[C07-27LY7KE5OO]] Mateo finally notices, laughs, then stops laughing.

[[C07-DLWOGAN4UH]] They debate stopping. Mateo argues ‘we can stop after we secure our lives’.

[[C07-24XEKVMQJH]] Zoë proposes one final controlled experiment to send a warning to themselves, small and testable.

[[C07-AT4UBGMBM3]] Mateo agrees, but his eyes are on the jackpot amount.

[[C07-IMT6D5WWTN]] Ortega’s team finds a tiny irregularity in service corridor access logs.

[[C07-XBAF4KWNKT]] Baeza meets Zoë alone and tells her a story about accidents that look like fate.

[[C07-RQ773UXEPC]] Zoë returns with a hard boundary: one final attempt, then burn it all.

[[C07-APYHNSQNZL]] Mateo nods, then drafts a plan that violates the boundary in three places.

[[C07-YG2K75BBNW]] They receive tomorrow’s numbers earlier than ever, and the window feels like it is widening.

[[C07-3AYFXPUSPC]] Zoë suspects the window widens because they are pulling harder, like stretching elastic.

[[C07-H23A2FPPKD]] End: Marina sends an anonymous message: ‘Nice trick. Want to talk?’
