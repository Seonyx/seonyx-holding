# Chapter 03 - Voyager’s Whisper

## POV
Mateo (third-person limited)

## Setting
Rooftop rig + online DSN forums

## Chapter purpose
- Move the plot: Mateo and Zoë meet Baeza, who treats them like a lab hazard with legs.
- Raise pressure: introduce a new constraint, threat, or moral fracture.
- End with a hook that forces the next chapter to exist.

## Beat map (high level)
- Beat 01: Mateo and Zoë meet Baeza, who treats them like a lab hazard with legs.
- Beat 02: Baeza explains DSS-63 in plain language: big dish, strict protocols, people who notice anomalies.
- Beat 03: Mateo pitches a ‘passive’ plan; Baeza laughs, because passive still leaves fingerprints.
- Beat 04: They learn about contractor routines, shift changes, and the town’s rhythm around the complex.
- Beat 05: Zoë insists on ethics: small test only, no money, no ripple.
- Beat 06: Mateo nods, already imagining a jackpot headline.
- Beat 07: They refine the experiment: send a trivial phrase, detect it yesterday, confirm causality loop.
- Beat 08: Mateo chooses the phrase: ‘Procrastination is the thief of time.’
- Beat 09: Zoë notes how a motto can become a trigger, like a psychological landmine.
- Beat 10: They run a simulated timing chain and find the error budget is brutal.
- Beat 11: A near-failure teaches them the real antagonist: noise, drift, and their own impatience.
- Beat 12: Mateo suggests a ‘field trip’ to Robledo with fake contractor badges.
- Beat 13: Zoë agrees, then surprises herself with the thrill of it.
- Beat 14: On the road to Robledo, they pick up a radio station playing a jingle Zoë swears never existed.
- Beat 15: Mateo doesn’t notice; Zoë does, and her stomach drops.
- Beat 16: End: DSS-63 appears on the horizon like a moon on stilts.

## Draft Paragraphs (keyed)

[[C03-E7XBWMTQXR]] Mateo and Zoë meet Baeza, who treats them like a lab hazard with legs.

[[C03-AUOWXTQ4UH]] Baeza explains DSS-63 in plain language: big dish, strict protocols, people who notice anomalies.

[[C03-I324C24CCE]] Mateo pitches a ‘passive’ plan; Baeza laughs, because passive still leaves fingerprints.

[[C03-LUAOYNXCKW]] They learn about contractor routines, shift changes, and the town’s rhythm around the complex.

[[C03-C44GFJQUAI]] Zoë insists on ethics: small test only, no money, no ripple.

[[C03-AKJOYKUTL3]] Mateo nods, already imagining a jackpot headline.

[[C03-5GHFSNOGPL]] They refine the experiment: send a trivial phrase, detect it yesterday, confirm causality loop.

[[C03-XJ6WMPQ3NP]] Mateo chooses the phrase: ‘Procrastination is the thief of time.’

[[C03-MCFLIAWTLF]] Zoë notes how a motto can become a trigger, like a psychological landmine.

[[C03-RM3V7NBIHI]] They run a simulated timing chain and find the error budget is brutal.

[[C03-CBDBX32PDT]] A near-failure teaches them the real antagonist: noise, drift, and their own impatience.

[[C03-SOBONGDOHB]] Mateo suggests a ‘field trip’ to Robledo with fake contractor badges.

[[C03-SGOM4QKJGR]] Zoë agrees, then surprises herself with the thrill of it.

[[C03-MDQ5BSXWAZ]] On the road to Robledo, they pick up a radio station playing a jingle Zoë swears never existed.

[[C03-J3VIRUWYUJ]] Mateo doesn’t notice; Zoë does, and her stomach drops.

[[C03-SUXYPGGBKL]] End: DSS-63 appears on the horizon like a moon on stilts.
