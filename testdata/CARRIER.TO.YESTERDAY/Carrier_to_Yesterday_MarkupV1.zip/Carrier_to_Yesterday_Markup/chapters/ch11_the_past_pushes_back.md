# Chapter 11 - The Past Pushes Back

## POV
Mateo (third-person limited)

## Setting
Madrid, crisis meeting + ultimatum

## Chapter purpose
- Move the plot: Mateo and Zoë interpret the crash-timestamp as a challenge, not a warning.
- Raise pressure: introduce a new constraint, threat, or moral fracture.
- End with a hook that forces the next chapter to exist.

## Beat map (high level)
- Beat 01: Mateo and Zoë interpret the crash-timestamp as a challenge, not a warning.
- Beat 02: They try to map the crash to a location using traffic data and satellite imagery.
- Beat 03: Zoë argues this proves the loop is already punishing them; Mateo argues it proves the loop is real.
- Beat 04: Ortega tightens the net and requests cooperation from national agencies.
- Beat 05: Marina demands commitment: either partner or become liability.
- Beat 06: Zoë decides they must send a message that makes the crash avoidable, without telling them to avoid it directly.
- Beat 07: Mateo writes a message full of coded caution, but his wording prioritises secrecy over clarity.
- Beat 08: They transmit the coded caution and later receive it early, but misread it the same way their past selves will.
- Beat 09: Zoë realises they are watching their own misunderstanding in real time.
- Beat 10: Mateo insists they can outsmart the loop with one more correction.
- Beat 11: They prepare for the final run: cash-out logistics, claim windows, travel route, burner phones.
- Beat 12: Ortega makes a move: an unmarked car tail appears in their mirrors.
- Beat 13: Zoë almost bails. Mateo almost lets her. Neither does.
- Beat 14: Baeza phones Zoë and says: ‘Time is not a tool. It’s a habitat.’
- Beat 15: Mateo deletes their lab files, but keeps a backup, because he cannot let go.
- Beat 16: End: they commit to the night drive to Robledo for the ‘final’ operation.

## Draft Paragraphs (keyed)

[[C11-ATGXM5DJR5]] Mateo and Zoë interpret the crash-timestamp as a challenge, not a warning.

[[C11-4RZ5FHFOLP]] They try to map the crash to a location using traffic data and satellite imagery.

[[C11-YBFEL4VXDZ]] Zoë argues this proves the loop is already punishing them; Mateo argues it proves the loop is real.

[[C11-TITL2XZGUP]] Ortega tightens the net and requests cooperation from national agencies.

[[C11-4H4TDGWHJ7]] Marina demands commitment: either partner or become liability.

[[C11-EHEMNZVAPE]] Zoë decides they must send a message that makes the crash avoidable, without telling them to avoid it directly.

[[C11-2BHLM76MT5]] Mateo writes a message full of coded caution, but his wording prioritises secrecy over clarity.

[[C11-LUQ4VBGIJT]] They transmit the coded caution and later receive it early, but misread it the same way their past selves will.

[[C11-ZWTH2Q3RKO]] Zoë realises they are watching their own misunderstanding in real time.

[[C11-H5STQYLJPU]] Mateo insists they can outsmart the loop with one more correction.

[[C11-WKKFP3S5MN]] They prepare for the final run: cash-out logistics, claim windows, travel route, burner phones.

[[C11-WCTZGHD4Y5]] Ortega makes a move: an unmarked car tail appears in their mirrors.

[[C11-D44QBJ36YR]] Zoë almost bails. Mateo almost lets her. Neither does.

[[C11-JHQPHSJYAB]] Baeza phones Zoë and says: ‘Time is not a tool. It’s a habitat.’

[[C11-YTETMOSK7C]] Mateo deletes their lab files, but keeps a backup, because he cannot let go.

[[C11-7BXKQ6YVQ2]] End: they commit to the night drive to Robledo for the ‘final’ operation.
