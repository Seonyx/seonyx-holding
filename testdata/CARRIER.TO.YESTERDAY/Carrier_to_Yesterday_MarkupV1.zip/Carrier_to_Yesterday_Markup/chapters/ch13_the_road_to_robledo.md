# Chapter 13 - The Road to Robledo

## POV
Mateo (third-person limited)

## Setting
Night drive, ticking clock

## Chapter purpose
- Move the plot: Mateo drives; Zoë monitors the live signal feed, headphones on, ears in two days at once.
- Raise pressure: introduce a new constraint, threat, or moral fracture.
- End with a hook that forces the next chapter to exist.

## Beat map (high level)
- Beat 01: Mateo drives; Zoë monitors the live signal feed, headphones on, ears in two days at once.
- Beat 02: They argue about route choice: fastest vs safest. Mateo chooses fastest.
- Beat 03: A new early signal arrives, distorted by wind and engine harmonics.
- Beat 04: Zoë tries to parse it and misses a curve warning sign.
- Beat 05: Ortega’s unmarked car keeps distance, waiting for the moment they make a mistake.
- Beat 06: Marina’s car closes in, flashing headlights like a demand.
- Beat 07: Mateo accelerates. Speed becomes a third character.
- Beat 08: Zoë hears their motto in the noise, half-swallowed: ‘Procrastination…’
- Beat 09: Mateo glances at Zoë instead of the road, needing reassurance he will not get.
- Beat 10: A deer, or a dog, or a patch of gravel, appears because tragedy loves banal triggers.
- Beat 11: Mateo swerves. The tyres scream a sentence the loop can’t redact.
- Beat 12: Impact is imminent. Zoë’s last coherent thought is that the timestamp was never a warning, it was a receipt.
- Beat 13: Metal folds. The signal spikes. Time becomes white noise.
- Beat 14: Ortega stops, stunned, then becomes a professional again.
- Beat 15: Marina’s car slows, then flees, because opportunists don’t like blood on them.
- Beat 16: End: emergency lights paint the dish’s direction on the sky, like a mockery.

## Draft Paragraphs (keyed)

[[C13-POCA3LOMP6]] Mateo drives; Zoë monitors the live signal feed, headphones on, ears in two days at once.

[[C13-FMCYJBAGUP]] They argue about route choice: fastest vs safest. Mateo chooses fastest.

[[C13-5NFF7UWXOD]] A new early signal arrives, distorted by wind and engine harmonics.

[[C13-RLKP5I34KX]] Zoë tries to parse it and misses a curve warning sign.

[[C13-Y7L7BRSHGY]] Ortega’s unmarked car keeps distance, waiting for the moment they make a mistake.

[[C13-7JSASGYG7A]] Marina’s car closes in, flashing headlights like a demand.

[[C13-DZ2JAVWUA6]] Mateo accelerates. Speed becomes a third character.

[[C13-RQF6YAIU5B]] Zoë hears their motto in the noise, half-swallowed: ‘Procrastination…’

[[C13-6TDZ2M57IG]] Mateo glances at Zoë instead of the road, needing reassurance he will not get.

[[C13-3MNWKRGECH]] A deer, or a dog, or a patch of gravel, appears because tragedy loves banal triggers.

[[C13-XFIU7RM4W6]] Mateo swerves. The tyres scream a sentence the loop can’t redact.

[[C13-YD5YG7DQ7S]] Impact is imminent. Zoë’s last coherent thought is that the timestamp was never a warning, it was a receipt.

[[C13-WQ2D3XDWQC]] Metal folds. The signal spikes. Time becomes white noise.

[[C13-LMH2IPMMVC]] Ortega stops, stunned, then becomes a professional again.

[[C13-6AN6P235TT]] Marina’s car slows, then flees, because opportunists don’t like blood on them.

[[C13-QBNFRJLF4R]] End: emergency lights paint the dish’s direction on the sky, like a mockery.
