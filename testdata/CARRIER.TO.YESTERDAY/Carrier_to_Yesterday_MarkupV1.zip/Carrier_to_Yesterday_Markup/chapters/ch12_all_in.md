# Chapter 12 - All-In

## POV
Zoë (third-person limited)

## Setting
Final plan, ethics collapse

## Chapter purpose
- Move the plot: Zoë narrates the final plan like a confession delivered to nobody.
- Raise pressure: introduce a new constraint, threat, or moral fracture.
- End with a hook that forces the next chapter to exist.

## Beat map (high level)
- Beat 01: Zoë narrates the final plan like a confession delivered to nobody.
- Beat 02: They receive the jackpot numbers early, and the thrill is almost quiet now.
- Beat 03: Mateo proposes a split: one of them drives, the other monitors the signal live.
- Beat 04: Zoë hates the idea, agrees anyway, and hates herself for agreeing.
- Beat 05: Marina demands a cut and sends muscle to ensure compliance.
- Beat 06: Ortega positions units along likely routes, but keeps it quiet to avoid panic and leaks.
- Beat 07: Zoë discovers a final history shift: a famous event in her memory now has a different date online.
- Beat 08: Mateo says, softly, ‘Maybe it was always like this.’
- Beat 09: They buy the ticket for the jackpot. The kiosk clerk wishes them luck, unaware of physics.
- Beat 10: Zoë writes meta-notes for herself, because she senses she will need them later.
- Beat 11: Mateo receives a new early signal: a fragment of their own voices shouting over engine noise.
- Beat 12: Zoë pleads to stop. Mateo says ‘after tonight’.
- Beat 13: They pack, wipe devices, and leave the city under sodium lights.
- Beat 14: Ortega’s tail locks on. The chase begins without anyone admitting it is a chase.
- Beat 15: Marina’s people follow too, creating a three-body problem with cars.
- Beat 16: End: the road sign reads ROBLEDO, and Zoë’s stomach drops as if gravity changed.

## Draft Paragraphs (keyed)

[[C12-2XD4EO7TQB]] Zoë narrates the final plan like a confession delivered to nobody.

[[C12-MQ232USRSY]] They receive the jackpot numbers early, and the thrill is almost quiet now.

[[C12-SZQ6ZZ4DUZ]] Mateo proposes a split: one of them drives, the other monitors the signal live.

[[C12-SCIVKJWYBI]] Zoë hates the idea, agrees anyway, and hates herself for agreeing.

[[C12-VNZP4WCVD7]] Marina demands a cut and sends muscle to ensure compliance.

[[C12-EH6OYHSHGG]] Ortega positions units along likely routes, but keeps it quiet to avoid panic and leaks.

[[C12-PFLOPRTQEW]] Zoë discovers a final history shift: a famous event in her memory now has a different date online.

[[C12-FKTH7NHLZZ]] Mateo says, softly, ‘Maybe it was always like this.’

[[C12-SXO4Q4UQBO]] They buy the ticket for the jackpot. The kiosk clerk wishes them luck, unaware of physics.

[[C12-5CCCYMK54D]] Zoë writes meta-notes for herself, because she senses she will need them later.

[[C12-VKOICAIC3Q]] Mateo receives a new early signal: a fragment of their own voices shouting over engine noise.

[[C12-C3SLYMKDLD]] Zoë pleads to stop. Mateo says ‘after tonight’.

[[C12-BRDGCQTJDN]] They pack, wipe devices, and leave the city under sodium lights.

[[C12-R2RUP3RNLO]] Ortega’s tail locks on. The chase begins without anyone admitting it is a chase.

[[C12-7PPUCKMFUJ]] Marina’s people follow too, creating a three-body problem with cars.

[[C12-ZKL33LRRCE]] End: the road sign reads ROBLEDO, and Zoë’s stomach drops as if gravity changed.
