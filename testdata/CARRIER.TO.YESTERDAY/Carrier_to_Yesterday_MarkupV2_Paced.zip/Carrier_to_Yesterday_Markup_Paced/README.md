# CTY Markup Pack - How this is meant to be used (Openclaw-friendly)

## What you have
- `00_master_story.md` - the story bible: rules, tone, cast, and the 15-chapter arc.
- `chapters/` - one file per chapter containing keyed paragraphs (currently a detailed beat-draft scaffold).
- `chapters_meta/` - one companion file per chapter containing keyed meta notes.

## The keyed-paragraph convention
Every paragraph begins with a unique stable key: `[[CXX-XXXXXXXXXX]]`.

Why:
- Paragraph numbers shift when you insert or delete.
- Keys do not shift. The meta stays welded to its paragraph.

### Example
Text file:
[[C01-ABCDE12345]] Mateo notices the signal is too clean to be noise.

Meta file:
[[C01-ABCDE12345]] Establish credibility of the anomaly; show Mateo’s pattern-hunger; plant the “too clean” clue.

## Guidance for the writing agent
When converting this scaffold into prose:
1. Preserve keys at the start of each paragraph.
2. Expand each scaffold paragraph into final prose, or split into multiple paragraphs as needed.
3. When splitting, keep the original key on the first paragraph and mint new keys for the new paragraphs.
4. Maintain parallel structure: every key in text must exist in meta, and vice versa.

## Markup expectations
- Markdown headings are for structure.
- The actual novel paragraphs are the keyed paragraphs under “Draft Paragraphs”.



## Pacing / acceleration
This pack implements a deliberate tightening of scaffold length: chapters shorten within each act, and each act is ~5% shorter than the previous one. This helps an agent-generated draft ‘naturally’ accelerate.
