# Chapter 02 - The Paper Nobody Cites

## POV
Zoë (third-person limited)

## Setting
Madrid, library stacks + late-night café

## Chapter purpose
- Move the plot: Zoë narrates the library hunt, finding the cited paper buried like a scandal in the stacks.
- Raise pressure: introduce a new constraint, threat, or moral fracture.
- End with a hook that forces the next chapter to exist.

## Beat map (high level)
- Beat 01: Zoë narrates the library hunt, finding the cited paper buried like a scandal in the stacks.
- Beat 02: The paper reads like heresy: advanced solutions, boundary conditions, and the universe politely pretending not to notice.
- Beat 03: Zoë lists all the reasons it should be wrong, then realises none of them are proofs.
- Beat 04: She meets Mateo at a café; he arrives with a breadboard and the expression of a man who has not slept.
- Beat 05: They translate the paper into an experiment: narrow-band coherent carrier, precise timing, external relay candidate.
- Beat 06: Zoë suggests DSN links as the only plausible ‘ridiculous but real’ relay infrastructure.
- Beat 07: Mateo suggests Robledo by name, too casually, like he has already committed the crime in his head.
- Beat 08: Zoë pushes back: access, legality, consequences.
- Beat 09: Mateo counters with practicality: ‘We don’t need to break in, we just need to listen.’
- Beat 10: They build a better receiver chain and schedule a rooftop test at a time aligned with Voyager’s geometry (narratively).
- Beat 11: Zoë calls a retired DSN engineer contact: Dr. Celia Baeza.
- Beat 12: Baeza refuses, then asks one technical question that proves she is already interested.
- Beat 13: Zoë hears herself saying ‘hypothetically’ too many times.
- Beat 14: A new signal arrives, cleaner, like someone answering a call they expected.
- Beat 15: Zoë writes a warning in her notebook, then crosses it out and replaces it with a formula.
- Beat 16: End: Baeza texts an address in Robledo and a single line: ‘Don’t be idiots.’

- Beat 01: Zoë narrates the library hunt, finding the cited paper buried like a scandal in the stacks.
- Beat 02: The paper reads like heresy: advanced solutions, boundary conditions, and the universe politely pretending not to notice.
- Beat 03: Zoë annotates the margins with objections until the ink looks like a cage.
- Beat 04: Zoë lists all the reasons it should be wrong, then realises none of them are proofs.
- Beat 05: She meets Mateo at a café; he arrives with a breadboard and the expression of a man who has not slept.
- Beat 06: They translate the paper into an experiment: narrow-band coherent carrier, precise timing, external relay candidate.
- Beat 07: Zoë suggests DSN links as the only plausible ‘ridiculous but real’ relay infrastructure.
- Beat 08: Mateo suggests Robledo by name, too casually, like he has already committed the crime in his head.
- Beat 09: Zoë pushes back: access, legality, consequences.
- Beat 10: Mateo counters with practicality: ‘We don’t need to break in, we just need to listen.’
- Beat 11: They build a better receiver chain and schedule a rooftop test at a time aligned with Voyager’s geometry (narratively).
- Beat 12: Zoë calls a retired DSN engineer contact: Dr. Celia Baeza.
- Beat 13: Baeza refuses, then asks one technical question that proves she is already interested.
- Beat 14: Zoë hears herself saying ‘hypothetically’ too many times.
- Beat 15: A new signal arrives, cleaner, like someone answering a call they expected.
- Beat 16: Zoë writes a warning in her notebook, then crosses it out and replaces it with a formula.
- Beat 17: End: Baeza texts an address in Robledo and a single line: ‘Don’t be idiots.’

## Draft Paragraphs (keyed)

[[C02-I26G675ZW3]] Zoë narrates the library hunt, finding the cited paper buried like a scandal in the stacks.

[[C02-L4CLRXGWDE]] The paper reads like heresy: advanced solutions, boundary conditions, and the universe politely pretending not to notice.

[[C02-PQ6D5RT7BI]] Zoë annotates the margins with objections until the ink looks like a cage.

[[C02-ZLJQ7QNRYX]] Zoë lists all the reasons it should be wrong, then realises none of them are proofs.

[[C02-JLBMP2IHH4]] She meets Mateo at a café; he arrives with a breadboard and the expression of a man who has not slept.

[[C02-KNVI3JITH6]] They translate the paper into an experiment: narrow-band coherent carrier, precise timing, external relay candidate.

[[C02-IKGWN4XL4G]] Zoë suggests DSN links as the only plausible ‘ridiculous but real’ relay infrastructure.

[[C02-MT4EJKAK6A]] Mateo suggests Robledo by name, too casually, like he has already committed the crime in his head.

[[C02-G6HVHDTV7Q]] Zoë pushes back: access, legality, consequences.

[[C02-2OUAT3UPEI]] Mateo counters with practicality: ‘We don’t need to break in, we just need to listen.’

[[C02-ZR7ZAOCXDA]] They build a better receiver chain and schedule a rooftop test at a time aligned with Voyager’s geometry (narratively).

[[C02-H4RC3Y3HTO]] Zoë calls a retired DSN engineer contact: Dr. Celia Baeza.

[[C02-6AWO6MRJ74]] Baeza refuses, then asks one technical question that proves she is already interested.

[[C02-Q7KDAKY4Y7]] Zoë hears herself saying ‘hypothetically’ too many times.

[[C02-MJBGGM7LPC]] A new signal arrives, cleaner, like someone answering a call they expected.

[[C02-GLNQ36MWT6]] Zoë writes a warning in her notebook, then crosses it out and replaces it with a formula.

[[C02-V4EEAGXTXS]] End: Baeza texts an address in Robledo and a single line: ‘Don’t be idiots.’
