# Chapter 14 - Impact

## POV
Zoë (third-person limited)

## Setting
Roadside, collision and aftermath

## Chapter purpose
- Move the plot: Zoë survives long enough to be conscious in fragments: sirens, glass, someone saying her name wrong.
- Raise pressure: introduce a new constraint, threat, or moral fracture.
- End with a hook that forces the next chapter to exist.

## Beat map (high level)
- Beat 01: Zoë survives long enough to be conscious in fragments: sirens, glass, someone saying her name wrong.
- Beat 02: Mateo’s absence is felt before it is known, a hole with edges.
- Beat 03: Ortega tries to question her gently, then not gently, then realises there is nothing coherent to extract.
- Beat 04: Zoë’s phone reboots and shows an old message thread rewritten, as if reality is tidying up.
- Beat 05: Baeza arrives at the hospital, fury wrapped around grief.
- Beat 06: Zoë learns Mateo is dead (or unrecoverable) and feels the loop close like a door.
- Beat 07: Ortega seizes equipment. The files are corrupted. The evidence does not want to exist.
- Beat 08: Marina disappears, leaving Zoë to carry the whole moral weight alone.
- Beat 09: Zoë tries to explain the time-symmetric effect to a doctor and stops, because it sounds like madness.
- Beat 10: Baeza tells Zoë the cruelest truth: they did it to themselves, even if physics helped.
- Beat 11: Zoë asks if she can send a message to yesterday to save him. Baeza says nothing.
- Beat 12: A nurse turns on a TV. The news headline is the one Zoë saw early, but with different wording again.
- Beat 13: Ortega closes the case publicly as ‘reckless trespassers’. Privately he keeps one notebook.
- Beat 14: Zoë decides to write everything down as keyed notes, because memory is unreliable now.
- Beat 15: She hears, faintly, the clean spike again on a hospital monitor speaker, impossible and familiar.
- Beat 16: End: Zoë whispers the motto and realises she is the one who taught it to herself.

- Beat 01: Zoë survives long enough to be conscious in fragments: sirens, glass, someone saying her name wrong.
- Beat 02: Mateo’s absence is felt before it is known, a hole with edges.
- Beat 03: Ortega tries to question her gently, then not gently, then realises there is nothing coherent to extract.
- Beat 04: Zoë’s phone reboots and shows an old message thread rewritten, as if reality is tidying up.
- Beat 05: Baeza arrives at the hospital, fury wrapped around grief.
- Beat 06: Zoë learns Mateo is dead (or unrecoverable) and feels the loop close like a door.
- Beat 07: Ortega seizes equipment. The files are corrupted. The evidence does not want to exist.
- Beat 08: Marina disappears, leaving Zoë to carry the whole moral weight alone.
- Beat 09: Zoë tries to explain the time-symmetric effect to a doctor and stops, because it sounds like madness.
- Beat 10: Baeza tells Zoë the cruelest truth: they did it to themselves, even if physics helped.
- Beat 11: Zoë asks if she can send a message to yesterday to save him. Baeza says nothing.
- Beat 12: A nurse turns on a TV. The news headline is the one Zoë saw early, but with different wording again.
- Beat 13: Ortega closes the case publicly as ‘reckless trespassers’. Privately he keeps one notebook.
- Beat 14: Zoë decides to write everything down as keyed notes, because memory is unreliable now. / She hears, faintly, the clean spike again on a hospital monitor speaker, impossible and familiar. / End: Zoë whispers the motto and realises she is the one who taught it to herself.

## Draft Paragraphs (keyed)

[[C14-QVXZ45PH7P]] Zoë survives long enough to be conscious in fragments: sirens, glass, someone saying her name wrong.

[[C14-XPDIZGDDMT]] Mateo’s absence is felt before it is known, a hole with edges.

[[C14-PFYLBJIHNE]] Ortega tries to question her gently, then not gently, then realises there is nothing coherent to extract.

[[C14-V2VH3MXYMY]] Zoë’s phone reboots and shows an old message thread rewritten, as if reality is tidying up.

[[C14-JWIMWDOXV5]] Baeza arrives at the hospital, fury wrapped around grief.

[[C14-4GTSIVGNE2]] Zoë learns Mateo is dead (or unrecoverable) and feels the loop close like a door.

[[C14-UNZQTTPE34]] Ortega seizes equipment. The files are corrupted. The evidence does not want to exist.

[[C14-5KQMJYUZ3J]] Marina disappears, leaving Zoë to carry the whole moral weight alone.

[[C14-YXA7EZBFUK]] Zoë tries to explain the time-symmetric effect to a doctor and stops, because it sounds like madness.

[[C14-WR6J5BGLD5]] Baeza tells Zoë the cruelest truth: they did it to themselves, even if physics helped.

[[C14-2R3PI3B2B3]] Zoë asks if she can send a message to yesterday to save him. Baeza says nothing.

[[C14-CC3JTFPPCY]] A nurse turns on a TV. The news headline is the one Zoë saw early, but with different wording again.

[[C14-6ZFSZDA3QU]] Ortega closes the case publicly as ‘reckless trespassers’. Privately he keeps one notebook.

[[C14-QPTF4H6L6C]] Zoë decides to write everything down as keyed notes, because memory is unreliable now. / She hears, faintly, the clean spike again on a hospital monitor speaker, impossible and familiar. / End: Zoë whispers the motto and realises she is the one who taught it to herself.
