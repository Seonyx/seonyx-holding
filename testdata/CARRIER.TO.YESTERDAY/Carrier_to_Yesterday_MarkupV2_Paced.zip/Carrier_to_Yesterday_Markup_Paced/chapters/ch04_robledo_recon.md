# Chapter 04 - Robledo Recon

## POV
Zoë (third-person limited)

## Setting
Robledo de Chavela, perimeter + town

## Chapter purpose
- Move the plot: Zoë leads the recon like a cautious thief, mapping gates, cameras, and human habits.
- Raise pressure: introduce a new constraint, threat, or moral fracture.
- End with a hook that forces the next chapter to exist.

## Beat map (high level)
- Beat 01: Zoë leads the recon like a cautious thief, mapping gates, cameras, and human habits.
- Beat 02: They blend into the town: café, petrol station, casual questions that are not casual.
- Beat 03: Mateo spots a maintenance van schedule; his eyes glitter with terrible ideas.
- Beat 04: Baeza gives them a lecture about consequences dressed as sarcasm.
- Beat 05: They secure a brief access window via a contractor handoff and a borrowed ID.
- Beat 06: Zoë insists on an exit plan before an entry plan, like an adult in a room of children.
- Beat 07: Inside the complex perimeter, everything is too clean, too calm, too monitored.
- Beat 08: Mateo is struck by the dish’s scale, and the reverence makes him reckless.
- Beat 09: They reach a service corridor, connect a small inline device, and pray nobody checks the logs.
- Beat 10: Zoë’s internal monologue runs like a checklist; Mateo’s runs like a victory speech.
- Beat 11: They transmit the phrase into the chain, a whisper into a cathedral microphone.
- Beat 12: Nothing happens. For a breath, it is just stupidity and trespass.
- Beat 13: A faint return appears on their gear, timestamped yesterday.
- Beat 14: Zoë feels triumph and nausea at the same time.
- Beat 15: They leave without sirens, which is somehow worse than leaving with sirens.
- Beat 16: End: a security console logs a tiny anomaly, and Chief Ortega frowns.

- Beat 01: Zoë leads the recon like a cautious thief, mapping gates, cameras, and human habits.
- Beat 02: They blend into the town: café, petrol station, casual questions that are not casual.
- Beat 03: Mateo spots a maintenance van schedule; his eyes glitter with terrible ideas.
- Beat 04: Baeza gives them a lecture about consequences dressed as sarcasm.
- Beat 05: They secure a brief access window via a contractor handoff and a borrowed ID.
- Beat 06: Zoë insists on an exit plan before an entry plan, like an adult in a room of children.
- Beat 07: Inside the complex perimeter, everything is too clean, too calm, too monitored.
- Beat 08: Mateo is struck by the dish’s scale, and the reverence makes him reckless.
- Beat 09: They reach a service corridor, connect a small inline device, and pray nobody checks the logs.
- Beat 10: Zoë’s internal monologue runs like a checklist; Mateo’s runs like a victory speech.
- Beat 11: They transmit the phrase into the chain, a whisper into a cathedral microphone.
- Beat 12: Nothing happens. For a breath, it is just stupidity and trespass.
- Beat 13: A faint return appears on their gear, timestamped yesterday.
- Beat 14: Zoë feels triumph and nausea at the same time.
- Beat 15: They leave without sirens, which is somehow worse than leaving with sirens. / End: a security console logs a tiny anomaly, and Chief Ortega frowns.

## Draft Paragraphs (keyed)

[[C04-7TNTBL3TAI]] Zoë leads the recon like a cautious thief, mapping gates, cameras, and human habits.

[[C04-ZK5ZE72NG7]] They blend into the town: café, petrol station, casual questions that are not casual.

[[C04-MPBYGZYJPI]] Mateo spots a maintenance van schedule; his eyes glitter with terrible ideas.

[[C04-SGZI6CTCZH]] Baeza gives them a lecture about consequences dressed as sarcasm.

[[C04-5CJCX7V36M]] They secure a brief access window via a contractor handoff and a borrowed ID.

[[C04-CSHJY3BXGN]] Zoë insists on an exit plan before an entry plan, like an adult in a room of children.

[[C04-BDPS7Z4MKT]] Inside the complex perimeter, everything is too clean, too calm, too monitored.

[[C04-HUNHOGDK6T]] Mateo is struck by the dish’s scale, and the reverence makes him reckless.

[[C04-ARQOM4H3OT]] They reach a service corridor, connect a small inline device, and pray nobody checks the logs.

[[C04-WQFK2LW7L3]] Zoë’s internal monologue runs like a checklist; Mateo’s runs like a victory speech.

[[C04-4WM52THMVR]] They transmit the phrase into the chain, a whisper into a cathedral microphone.

[[C04-IGP24LBXTF]] Nothing happens. For a breath, it is just stupidity and trespass.

[[C04-DJ3EZB42II]] A faint return appears on their gear, timestamped yesterday.

[[C04-3LXA56YWER]] Zoë feels triumph and nausea at the same time.

[[C04-ME2XHIDPYQ]] They leave without sirens, which is somehow worse than leaving with sirens. / End: a security console logs a tiny anomaly, and Chief Ortega frowns.
