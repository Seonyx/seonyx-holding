# Chapter 09 - The Dish Notices

## POV
Mateo (third-person limited)

## Setting
Robledo, security attention

## Chapter purpose
- Move the plot: Mateo feels targeted, as if reality learned his name from a leak.
- Raise pressure: introduce a new constraint, threat, or moral fracture.
- End with a hook that forces the next chapter to exist.

## Beat map (high level)
- Beat 01: Mateo feels targeted, as if reality learned his name from a leak.
- Beat 02: Ortega reviews CCTV and spots two figures moving like they do not belong.
- Beat 03: Mateo and Zoë prepare for Robledo: tools, disguises, plausible lies.
- Beat 04: Zoë insists on an exit strategy that includes destroying evidence and quitting.
- Beat 05: Mateo privately sets a second objective: secure a bigger data pipe for a jackpot play.
- Beat 06: Marina arrives in person, offering help and demonstrating she knows too much.
- Beat 07: Zoë refuses; Marina smiles like someone hearing ‘maybe’.
- Beat 08: At Robledo, security is thicker. Ortega is visible now, a man-shaped lock.
- Beat 09: They slip in via a contractor corridor, but every step feels pre-remembered.
- Beat 10: Mateo sees the dish control readouts and feels the rush of being near godlike hardware.
- Beat 11: Zoë notices a sign with a slogan she is sure was not there last time.
- Beat 12: They execute the plan: brief tap, quick transmit, quick capture.
- Beat 13: Ortega’s team flags the anomaly in real time this time.
- Beat 14: They flee the perimeter. No sirens yet, but the night feels hunted.
- Beat 15: Back in the car, Mateo admits Marina is involved. Zoë goes cold.
- Beat 16: End: Ortega orders a quiet pursuit. ‘No noise. Bring them in.’

- Beat 01: Mateo feels targeted, as if reality learned his name from a leak.
- Beat 02: Ortega reviews CCTV and spots two figures moving like they do not belong.
- Beat 03: Mateo and Zoë prepare for Robledo: tools, disguises, plausible lies.
- Beat 04: Zoë insists on an exit strategy that includes destroying evidence and quitting.
- Beat 05: Mateo privately sets a second objective: secure a bigger data pipe for a jackpot play.
- Beat 06: Marina arrives in person, offering help and demonstrating she knows too much.
- Beat 07: Zoë refuses; Marina smiles like someone hearing ‘maybe’.
- Beat 08: At Robledo, security is thicker. Ortega is visible now, a man-shaped lock.
- Beat 09: They slip in via a contractor corridor, but every step feels pre-remembered.
- Beat 10: Mateo sees the dish control readouts and feels the rush of being near godlike hardware.
- Beat 11: Zoë notices a sign with a slogan she is sure was not there last time.
- Beat 12: They execute the plan: brief tap, quick transmit, quick capture.
- Beat 13: Ortega’s team flags the anomaly in real time this time.
- Beat 14: They flee the perimeter. No sirens yet, but the night feels hunted. / Back in the car, Mateo admits Marina is involved. Zoë goes cold. / End: Ortega orders a quiet pursuit. ‘No noise. Bring them in.’

## Draft Paragraphs (keyed)

[[C09-W33PJOCMFA]] Mateo feels targeted, as if reality learned his name from a leak.

[[C09-BPFSIPHTZK]] Ortega reviews CCTV and spots two figures moving like they do not belong.

[[C09-UMEEHK47HM]] Mateo and Zoë prepare for Robledo: tools, disguises, plausible lies.

[[C09-VRCNWOP2MJ]] Zoë insists on an exit strategy that includes destroying evidence and quitting.

[[C09-AE4LP4C2WO]] Mateo privately sets a second objective: secure a bigger data pipe for a jackpot play.

[[C09-5HIJE5TEBP]] Marina arrives in person, offering help and demonstrating she knows too much.

[[C09-APRMRNMNZS]] Zoë refuses; Marina smiles like someone hearing ‘maybe’.

[[C09-7RD4OGPILD]] At Robledo, security is thicker. Ortega is visible now, a man-shaped lock.

[[C09-LSHVMTIJ5Y]] They slip in via a contractor corridor, but every step feels pre-remembered.

[[C09-YWWYYV4APF]] Mateo sees the dish control readouts and feels the rush of being near godlike hardware.

[[C09-7EDAVD23QA]] Zoë notices a sign with a slogan she is sure was not there last time.

[[C09-YPLNZM7YFW]] They execute the plan: brief tap, quick transmit, quick capture.

[[C09-EQWAYKPFNZ]] Ortega’s team flags the anomaly in real time this time.

[[C09-Y4AGLD65GG]] They flee the perimeter. No sirens yet, but the night feels hunted. / Back in the car, Mateo admits Marina is involved. Zoë goes cold. / End: Ortega orders a quiet pursuit. ‘No noise. Bring them in.’
