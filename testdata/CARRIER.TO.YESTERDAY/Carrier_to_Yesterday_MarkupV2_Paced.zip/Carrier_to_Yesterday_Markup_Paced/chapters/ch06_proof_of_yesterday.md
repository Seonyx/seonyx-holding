# Chapter 06 - Proof of Yesterday

## POV
Zoë (third-person limited)

## Setting
Back in Madrid, lab pressure cooker

## Chapter purpose
- Move the plot: Zoë formalises the ‘rules of the loop’ on a whiteboard, as if naming a beast makes it tame.
- Raise pressure: introduce a new constraint, threat, or moral fracture.
- End with a hook that forces the next chapter to exist.

## Beat map (high level)
- Beat 01: Zoë formalises the ‘rules of the loop’ on a whiteboard, as if naming a beast makes it tame.
- Beat 02: Mateo builds a more discreet rig, improving gain while increasing risk.
- Beat 03: They notice the loop responds to attention: the more they probe, the more ‘echoes’ appear.
- Beat 04: Zoë catches another micro-shift: an old photo online has a different background than she remembers.
- Beat 05: Mateo calls it false memory. Zoë hates that he might be right.
- Beat 06: They decide to run one more lottery test, slightly bigger, ‘for statistical confidence’.
- Beat 07: Baeza cuts ties, then leaves them a spare part anyway.
- Beat 08: A new player appears: Marina Ríos, pattern-hunting on public results and social chatter.
- Beat 09: Ortega installs extra logging and begins to correlate anomalies with time windows.
- Beat 10: Zoë writes a private note: ‘If we can do this, someone else can.’
- Beat 11: Mateo proposes a syndicate plan. Zoë refuses, then asks ‘hypothetically, how?’
- Beat 12: Their second win is larger and louder. Money makes physics visible.
- Beat 13: A journalist posts about ‘a suspicious streak’ on a forum Marina follows.
- Beat 14: Ortega requests CCTV pulls from the night of their recon.
- Beat 15: Zoë starts keeping two notebooks: one for equations, one for guilt.
- Beat 16: End: the signal delivers a phrase that is not theirs, like a stranger using their phone.

- Beat 01: Zoë formalises the ‘rules of the loop’ on a whiteboard, as if naming a beast makes it tame.
- Beat 02: She adds a final rule in smaller writing: ‘No one can be trusted with this, including us.’
- Beat 03: Mateo builds a more discreet rig, improving gain while increasing risk.
- Beat 04: They notice the loop responds to attention: the more they probe, the more ‘echoes’ appear.
- Beat 05: Zoë catches another micro-shift: an old photo online has a different background than she remembers.
- Beat 06: Mateo calls it false memory. Zoë hates that he might be right.
- Beat 07: They decide to run one more lottery test, slightly bigger, ‘for statistical confidence’.
- Beat 08: Baeza cuts ties, then leaves them a spare part anyway.
- Beat 09: A new player appears: Marina Ríos, pattern-hunting on public results and social chatter.
- Beat 10: Ortega installs extra logging and begins to correlate anomalies with time windows.
- Beat 11: Zoë writes a private note: ‘If we can do this, someone else can.’
- Beat 12: Mateo proposes a syndicate plan. Zoë refuses, then asks ‘hypothetically, how?’
- Beat 13: Their second win is larger and louder. Money makes physics visible.
- Beat 14: A journalist posts about ‘a suspicious streak’ on a forum Marina follows.
- Beat 15: Ortega requests CCTV pulls from the night of their recon.
- Beat 16: Zoë starts keeping two notebooks: one for equations, one for guilt.
- Beat 17: End: the signal delivers a phrase that is not theirs, like a stranger using their phone.

## Draft Paragraphs (keyed)

[[C06-NVRIS7U64I]] Zoë formalises the ‘rules of the loop’ on a whiteboard, as if naming a beast makes it tame.

[[C06-3SKVMEPR5N]] She adds a final rule in smaller writing: ‘No one can be trusted with this, including us.’

[[C06-S7SYWW3RWX]] Mateo builds a more discreet rig, improving gain while increasing risk.

[[C06-OXQ4MQNL7K]] They notice the loop responds to attention: the more they probe, the more ‘echoes’ appear.

[[C06-3QIHTFXNUC]] Zoë catches another micro-shift: an old photo online has a different background than she remembers.

[[C06-D3ZE3WEETR]] Mateo calls it false memory. Zoë hates that he might be right.

[[C06-EM25OTTOBL]] They decide to run one more lottery test, slightly bigger, ‘for statistical confidence’.

[[C06-OXVTM6KGZB]] Baeza cuts ties, then leaves them a spare part anyway.

[[C06-Q3VWBVINBN]] A new player appears: Marina Ríos, pattern-hunting on public results and social chatter.

[[C06-ENP2SUESJM]] Ortega installs extra logging and begins to correlate anomalies with time windows.

[[C06-XEK2PKIP7H]] Zoë writes a private note: ‘If we can do this, someone else can.’

[[C06-BYSVPD726X]] Mateo proposes a syndicate plan. Zoë refuses, then asks ‘hypothetically, how?’

[[C06-WDS7YJXQYN]] Their second win is larger and louder. Money makes physics visible.

[[C06-WPDGB4XFZS]] A journalist posts about ‘a suspicious streak’ on a forum Marina follows.

[[C06-HLQI4AHJ2C]] Ortega requests CCTV pulls from the night of their recon.

[[C06-T6VXMM2EB2]] Zoë starts keeping two notebooks: one for equations, one for guilt.

[[C06-EUUCBCNT2R]] End: the signal delivers a phrase that is not theirs, like a stranger using their phone.
