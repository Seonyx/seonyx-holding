# Chapter 15 - Carrier to Yesterday

## POV
Mateo (third-person limited)

## Setting
Coda: echoes, loop, last irony

## Chapter purpose
- Move the plot: Coda from Mateo’s close third, but with a ghostly distance: a reconstructed timeline montage.
- Raise pressure: introduce a new constraint, threat, or moral fracture.
- End with a hook that forces the next chapter to exist.

## Beat map (high level)
- Beat 01: Coda from Mateo’s close third, but with a ghostly distance: a reconstructed timeline montage.
- Beat 02: We revisit the seminar, the paper, the rooftop, now with small differences the reader notices.
- Beat 03: A DSN technician logs a faint anomaly and labels it ‘STATIC’, then changes it to ‘ANOMALY’.
- Beat 04: Ortega files his notebook away, but the notebook seems thicker than it should be.
- Beat 05: Marina reads a forum post about a ‘new’ method and smiles, because greed is evergreen.
- Beat 06: Baeza deletes a file, then restores it, then stares at the cursor like it is judging her.
- Beat 07: Zoë begins writing the story as a warning disguised as entertainment.
- Beat 08: The motto appears in a place it should not: a billboard, a tweet, a child’s notebook.
- Beat 09: The universe offers no moral lecture, only repeating patterns.
- Beat 10: A clean spike returns, now carrying a new phrase: ‘Next time, slower.’
- Beat 11: Zoë considers destroying the last rig, then keeps it in a box, because humans store their curses.
- Beat 12: The last image is the road to Robledo at night, empty, waiting.
- Beat 13: The last sound is white noise resolving, for a second, into two voices laughing.
- Beat 14: Then silence, like a page turning.
- Beat 15: Title drop in a document header: ‘Carrier to Yesterday’.
- Beat 16: End.

- Beat 01: Coda from Mateo’s close third, but with a ghostly distance: a reconstructed timeline montage.
- Beat 02: We revisit the seminar, the paper, the rooftop, now with small differences the reader notices.
- Beat 03: A DSN technician logs a faint anomaly and labels it ‘STATIC’, then changes it to ‘ANOMALY’.
- Beat 04: Ortega files his notebook away, but the notebook seems thicker than it should be.
- Beat 05: Marina reads a forum post about a ‘new’ method and smiles, because greed is evergreen.
- Beat 06: Baeza deletes a file, then restores it, then stares at the cursor like it is judging her.
- Beat 07: Zoë begins writing the story as a warning disguised as entertainment.
- Beat 08: The motto appears in a place it should not: a billboard, a tweet, a child’s notebook.
- Beat 09: The universe offers no moral lecture, only repeating patterns.
- Beat 10: A clean spike returns, now carrying a new phrase: ‘Next time, slower.’
- Beat 11: Zoë considers destroying the last rig, then keeps it in a box, because humans store their curses.
- Beat 12: The last image is the road to Robledo at night, empty, waiting.
- Beat 13: The last sound is white noise resolving, for a second, into two voices laughing. / Then silence, like a page turning. / Title drop in a document header: ‘Carrier to Yesterday’. / End.

## Draft Paragraphs (keyed)

[[C15-DJ5T3VZ364]] Coda from Mateo’s close third, but with a ghostly distance: a reconstructed timeline montage.

[[C15-UEUHPVJ7WK]] We revisit the seminar, the paper, the rooftop, now with small differences the reader notices.

[[C15-4JFN2QPNLN]] A DSN technician logs a faint anomaly and labels it ‘STATIC’, then changes it to ‘ANOMALY’.

[[C15-PL3VRYGD6Z]] Ortega files his notebook away, but the notebook seems thicker than it should be.

[[C15-24C73ZGNEV]] Marina reads a forum post about a ‘new’ method and smiles, because greed is evergreen.

[[C15-N46AQ5MWB7]] Baeza deletes a file, then restores it, then stares at the cursor like it is judging her.

[[C15-YTXGO5RZ6Z]] Zoë begins writing the story as a warning disguised as entertainment.

[[C15-B3ENRZQB52]] The motto appears in a place it should not: a billboard, a tweet, a child’s notebook.

[[C15-MN6ABUYIM5]] The universe offers no moral lecture, only repeating patterns.

[[C15-7WLHOYRLSX]] A clean spike returns, now carrying a new phrase: ‘Next time, slower.’

[[C15-6JS336PMC6]] Zoë considers destroying the last rig, then keeps it in a box, because humans store their curses.

[[C15-LVCCRMCH2T]] The last image is the road to Robledo at night, empty, waiting.

[[C15-O2PJB2HWLV]] The last sound is white noise resolving, for a second, into two voices laughing. / Then silence, like a page turning. / Title drop in a document header: ‘Carrier to Yesterday’. / End.
