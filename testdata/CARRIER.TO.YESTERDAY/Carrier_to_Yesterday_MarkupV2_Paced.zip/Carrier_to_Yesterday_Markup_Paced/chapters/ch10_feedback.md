# Chapter 10 - Feedback

## POV
Zoë (third-person limited)

## Setting
Madrid, reality “micro-shifts”

## Chapter purpose
- Move the plot: Zoë experiences a hard history shift: a childhood memory contradicts an old message thread on her phone.
- Raise pressure: introduce a new constraint, threat, or moral fracture.
- End with a hook that forces the next chapter to exist.

## Beat map (high level)
- Beat 01: Zoë experiences a hard history shift: a childhood memory contradicts an old message thread on her phone.
- Beat 02: Mateo tries to anchor with numbers and measurements, but even those begin to wobble.
- Beat 03: They receive multiple early signals for the same event, none matching perfectly.
- Beat 04: Zoë posits they are in a resonant cavity: their actions reflect, amplify, distort.
- Beat 05: Mateo is tempted to push harder, like gamblers doubling down on a losing hand.
- Beat 06: Ortega closes in, using telecom records and traffic cameras.
- Beat 07: Marina offers a safehouse and a plan to monetise the loop fully.
- Beat 08: Zoë confronts Mateo: choose the loop or choose her. Mateo hesitates.
- Beat 09: They attempt to send a ‘stop’ message to yesterday and receive it… already there, but garbled.
- Beat 10: Zoë realises the loop may be self-consistent: it allows only the mistakes that lead to it.
- Beat 11: Mateo breaks down briefly, then rebuilds his resolve into stubbornness.
- Beat 12: Baeza sends a final warning: Ortega has identified the corridor and will lock it down.
- Beat 13: Zoë proposes burning everything and leaving Madrid tonight.
- Beat 14: Mateo proposes one last jackpot to fund the disappearance.
- Beat 15: They choose the jackpot, because humans are predictable.
- Beat 16: End: the signal delivers a timestamp for tomorrow’s crash on the road to Robledo, but without context.

- Beat 01: Zoë experiences a hard history shift: a childhood memory contradicts an old message thread on her phone.
- Beat 02: Mateo tries to anchor with numbers and measurements, but even those begin to wobble.
- Beat 03: They receive multiple early signals for the same event, none matching perfectly.
- Beat 04: Zoë posits they are in a resonant cavity: their actions reflect, amplify, distort.
- Beat 05: Mateo is tempted to push harder, like gamblers doubling down on a losing hand.
- Beat 06: Ortega closes in, using telecom records and traffic cameras.
- Beat 07: Marina offers a safehouse and a plan to monetise the loop fully.
- Beat 08: Zoë confronts Mateo: choose the loop or choose her. Mateo hesitates.
- Beat 09: They attempt to send a ‘stop’ message to yesterday and receive it… already there, but garbled.
- Beat 10: Zoë realises the loop may be self-consistent: it allows only the mistakes that lead to it.
- Beat 11: Mateo breaks down briefly, then rebuilds his resolve into stubbornness.
- Beat 12: Baeza sends a final warning: Ortega has identified the corridor and will lock it down.
- Beat 13: Zoë proposes burning everything and leaving Madrid tonight.
- Beat 14: Mateo proposes one last jackpot to fund the disappearance. / They choose the jackpot, because humans are predictable. / End: the signal delivers a timestamp for tomorrow’s crash on the road to Robledo, but without context.

## Draft Paragraphs (keyed)

[[C10-FWZQZ6NGBY]] Zoë experiences a hard history shift: a childhood memory contradicts an old message thread on her phone.

[[C10-5IOC3BGNPX]] Mateo tries to anchor with numbers and measurements, but even those begin to wobble.

[[C10-CBVBPPFS7P]] They receive multiple early signals for the same event, none matching perfectly.

[[C10-TMRMH6UUMF]] Zoë posits they are in a resonant cavity: their actions reflect, amplify, distort.

[[C10-D7RHSEMF3Y]] Mateo is tempted to push harder, like gamblers doubling down on a losing hand.

[[C10-MWDI2KXREX]] Ortega closes in, using telecom records and traffic cameras.

[[C10-CXMSVQL4RM]] Marina offers a safehouse and a plan to monetise the loop fully.

[[C10-TNMDMITT2U]] Zoë confronts Mateo: choose the loop or choose her. Mateo hesitates.

[[C10-2OS2KCFCZ3]] They attempt to send a ‘stop’ message to yesterday and receive it… already there, but garbled.

[[C10-AL4GY6CZX5]] Zoë realises the loop may be self-consistent: it allows only the mistakes that lead to it.

[[C10-DYVFTI74YP]] Mateo breaks down briefly, then rebuilds his resolve into stubbornness.

[[C10-3WEPGUIER4]] Baeza sends a final warning: Ortega has identified the corridor and will lock it down.

[[C10-QCE2TCY5TL]] Zoë proposes burning everything and leaving Madrid tonight.

[[C10-NLTDX3XGAN]] Mateo proposes one last jackpot to fund the disappearance. / They choose the jackpot, because humans are predictable. / End: the signal delivers a timestamp for tomorrow’s crash on the road to Robledo, but without context.
