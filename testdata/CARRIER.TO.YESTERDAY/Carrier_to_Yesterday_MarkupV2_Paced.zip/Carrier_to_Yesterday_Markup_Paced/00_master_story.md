# Carrier to Yesterday (CTY) - Master Story File

Author credit: **Maureen Avis** (nom-de-plume)  
Working title: **Carrier to Yesterday**

## Core premise
Two undercooked engineers discover a time-symmetric radio trick: by using an advanced solution interpretation of Maxwell’s equations and a deep-space relay (Voyager transponder mode as a narrative device), they can **receive a coherent signal about a day in advance**. They aim low: lottery numbers. They learn high: time does not like being mugged.

## Tone
Techno-thriller caper with dry humour and creeping metaphysical dread. The science is treated seriously, the humans are not.

## Setting anchors
- Madrid, university labs, rooftops, late-night cafés.
- **Madrid Deep Space Communications Complex, Robledo de Chavela (DSS-63 dish)** as the main set-piece.
- Roads between Madrid and Robledo: the story’s “pressure tube” for the final act.

## Time mechanism (story rules)
1. A narrow-band coherent signal can be interpreted as arriving from “yesterday” when the system is tuned and relayed through the deep-space link.
2. The window is short: roughly **one day and a bit** (enough for urgency, not enough for omniscience).
3. The signal is fragile: interference, misalignment, human error, and countermeasures can corrupt it.
4. The loop has teeth: trying to exploit it creates feedback, including ambiguous “echoes” that look like warnings.

## Themes and motifs
- Shortcuts as a moral failing disguised as cleverness.
- History as a stitched quilt: tug one thread, patterns shift.
- Generational impatience: the future is mortgaged for a dopamine hit.
- Motif line: **“Procrastination is the thief of time.”**
- Irony as physics: the universe charges interest.

## Primary POV strategy
Third-person limited, alternating between the two protagonists.
- **Mateo Salas**: radio engineering graduate, obsessive, rationalising.
- **Zoë Kwan**: visiting physics candidate, sharp, skeptical, attracted to the audacity.

POV alternation guideline:
- Odd chapters: Mateo.
- Even chapters: Zoë.
(Adjust freely if a chapter demands the opposite.)

## Key cast (expand as needed)
- **Mateo Salas** (POV): builder, tinkerer, “we can totally do this”.
- **Zoë Kwan** (POV): theorist, debugger, “this is a terrible idea, let’s quantify it.”
- **Dr. Celia Baeza**: retired DSN engineer, reluctant consultant.
- **Chief Ortega**: security lead at Robledo, patient until he is not.
- **Marina Ríos**: lottery-syndicate operator who smells pattern and profit.
- **Javi**: contractor or guard, small kindness, big consequences.

## Story arc (15 chapters) with deliberate acceleration

Pacing design:
- **Within each act:** chapters get slightly shorter toward the act break.
- **Across the book:** each act is ~5% shorter than the one before, so the pace tightens as stakes rise.

Target “beat counts” (scaffold paragraphs) per chapter:
- Act I (Ch 1–5): 18, 17, 16, 15, 14
- Act II (Ch 6–10): 17, 16, 15, 14, 14
- Act III (Ch 11–15): 16, 15, 14, 14, 13

### Act I - Discovery and Proof (Ch 1-5)
1. Static in the Seminar
2. The Paper Nobody Cites
3. Voyager’s Whisper
4. Robledo Recon
5. The First Bounce

### Act II - Exploitation and Feedback (Ch 6-10)
6. Proof of Yesterday
7. A Modest Win
8. Signal-to-Noise
9. The Dish Notices
10. Feedback

### Act III - Compression and Consequence (Ch 11-15)
11. The Past Pushes Back
12. All-In
13. The Road to Robledo
14. Impact
15. Carrier to Yesterday (coda)


## Ending commitment
No “Don’t Go” escape hatch. The climax lands on **ironic car-crash tragedy**: the characters’ attempt to outrun time becomes a literal collision with it.

---

## How to use the keyed-paragraph system
Each chapter exists as two files:
- `chapters/chXX_*.md` contains the **chapter text** (draftable prose).
- `chapters_meta/chXX_*_meta.md` contains **meta notes**, keyed to the text.

Every paragraph begins with a stable unique key like:
`[[C03-7K2Q9ZP1AB]]`

Rules:
1. If you edit or reflow prose, **do not change keys**.
2. If you insert a new paragraph, generate a new key and add a matching meta entry.
3. If you delete a paragraph, delete the matching meta entry.
4. If you split one paragraph into two, keep the original key on the first, create a new key for the second, add a new meta entry.

