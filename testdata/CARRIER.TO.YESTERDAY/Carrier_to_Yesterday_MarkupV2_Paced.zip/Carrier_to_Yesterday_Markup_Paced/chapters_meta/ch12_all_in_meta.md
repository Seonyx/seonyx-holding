# Chapter 12 Meta Notes - All-In

## What this file is
Keyed meta notes aligned 1:1 with the chapter text paragraphs.

## Meta entries

[[C12-2XD4EO7TQB]] POV intensity; tone shift to inevitability.

[[C12-MQ232USRSY]] Greed matured into compulsion.

[[C12-SZQ6ZZ4DUZ]] Set up distraction for crash.

[[C12-SCIVKJWYBI]] Moral and emotional tension.

[[C12-VNZP4WCVD7]] External pressure.

[[C12-EH6OYHSHGG]] Antagonist strategy.

[[C12-PFLOPRTQEW]] Theme peak: constructed history.

[[C12-FKTH7NHLZZ]] Existential dread.

[[C12-SXO4Q4UQBO]] Ordinary meets cosmic.

[[C12-5CCCYMK54D]] Meta layer justification.

[[C12-VKOICAIC3Q]] Foreshadow crash audio.

[[C12-C3SLYMKDLD]] Last refusal.

[[C12-BRDGCQTJDN]] Atmosphere.

[[C12-R2RUP3RNLO]] Tension.

[[C12-7PPUCKMFUJ]] Complexity. + Act III launch.
