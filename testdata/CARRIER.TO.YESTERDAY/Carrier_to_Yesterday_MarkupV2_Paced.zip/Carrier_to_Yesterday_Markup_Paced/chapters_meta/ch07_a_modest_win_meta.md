# Chapter 07 Meta Notes - A Modest Win

## What this file is
Keyed meta notes aligned 1:1 with the chapter text paragraphs.

## Meta entries

[[C07-WMZ35OBVJK]] Character; tone.

[[C07-HVICDQ5XVS]] Inner conflict.

[[C07-7RGLRHMOOF]] Operational paranoia.

[[C07-PDEJXWG6EW]] Antagonist competence.

[[C07-VLDXXJTOSH]] Escalate constructed history.

[[C07-27LY7KE5OO]] Shared dread begins.

[[C07-DLWOGAN4UH]] Classic rationalisation.

[[C07-24XEKVMQJH]] Set up future echo attempts.

[[C07-AT4UBGMBM3]] Conflict.

[[C07-IMT6D5WWTN]] Threat grows.

[[C07-XBAF4KWNKT]] Mentor pushes theme.

[[C07-RQ773UXEPC]] Act II constraint.

[[C07-APYHNSQNZL]] Set up betrayal through omission.

[[C07-YG2K75BBNW]] Physics shift; danger.

[[C07-3AYFXPUSPC]] Foreshadow snapback.

[[C07-H23A2FPPKD]] External complication arrives.
