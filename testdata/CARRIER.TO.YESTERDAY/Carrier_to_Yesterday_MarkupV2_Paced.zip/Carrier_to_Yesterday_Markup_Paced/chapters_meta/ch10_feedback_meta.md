# Chapter 10 Meta Notes - Feedback

## What this file is
Keyed meta notes aligned 1:1 with the chapter text paragraphs.

## Meta entries

[[C10-FWZQZ6NGBY]] Big thematic reveal; destabilise reality.

[[C10-5IOC3BGNPX]] Science failing as comfort.

[[C10-CBVBPPFS7P]] Feedback literalised.

[[C10-TMRMH6UUMF]] Metaphor to physics.

[[C10-D7RHSEMF3Y]] Character.

[[C10-MWDI2KXREX]] Modern surveillance pressure.

[[C10-CXMSVQL4RM]] Antagonist as saviour.

[[C10-TNMDMITT2U]] Relationship crisis.

[[C10-2OS2KCFCZ3]] Attempted self-intervention fails.

[[C10-AL4GY6CZX5]] Determinism dread.

[[C10-DYVFTI74YP]] Emotional turn.

[[C10-3WEPGUIER4]] Mentor; ticking clock.

[[C10-QCE2TCY5TL]] New goal.

[[C10-NLTDX3XGAN]] Opposing goal. + Theme punch. + Foreshadow crash without ‘Don’t Go’.
