# Chapter 03 Meta Notes - Voyager’s Whisper

## What this file is
Keyed meta notes aligned 1:1 with the chapter text paragraphs.

## Meta entries

[[C03-E7XBWMTQXR]] Mentor dynamic; grounded expertise.

[[C03-AUOWXTQ4UH]] Worldbuilding; stakes.

[[C03-I324C24CCE]] Undercut; realism.

[[C03-LUAOYNXCKW]] Heist planning texture.

[[C03-C44GFJQUAI]] Set initial moral constraint.

[[C03-AKJOYKUTL3]] Foreshadow moral drift.

[[C03-5GHFSNOGPL]] Clarify goal: proof.

[[C03-XJ6WMPQ3NP]] Motif becomes action.

[[C03-MCFLIAWTLF]] Subtext; character insight.

[[C03-RM3V7NBIHI]] Introduce technical difficulty; avoid magic.

[[C03-CBDBX32PDT]] Antagonist shift from people to physics.

[[C03-SOBONGDOHB]] Escalation toward trespass.

[[C03-SGOM4QKJGR]] Zoë’s complicity.

[[C03-MDQ5BSXWAZ]] First ‘constructed history’ micro-shift.

[[C03-J3VIRUWYUJ]] POV-driven unease.

[[C03-SUXYPGGBKL]] Set-piece arrival.
