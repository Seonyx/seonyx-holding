# Chapter 01 Meta Notes - Static in the Seminar

## What this file is
Keyed meta notes aligned 1:1 with the chapter text paragraphs.

## Meta entries

[[C01-4E4JEXDWPR]] Hook and POV anchoring; plant the ‘impossible but specific’ clue.

[[C01-FN5MBFHZOF]] Characterise Mateo as fixation-prone; set up conflict with authority.

[[C01-3D6IIY5QAG]] Provide the inciting breadcrumb; show institutional indifference.

[[C01-CD472XEIOR]] Introduce tools; tone: serious tech with comic undertow.

[[C01-DZ3SGCBDKQ]] Introduce anomaly; make it measurable, not mystical.

[[C01-F3TRZEK66T]] Isolate the first ‘too clean’ spike as its own beat; make the anomaly feel undeniable.

[[C01-A76F33HVGU]] Show denial to obsession transition.

[[C01-6BCJYMREEO]] Introduce co-protagonist via relationship dynamic.

[[C01-P3CJJV3SUW]] Define Zoë’s voice: skeptical but rigorous.

[[C01-FC6LWB7TJX]] Foreshadow the ethical and conceptual debate.

[[C01-ICJJH7A4NL]] Plant Voyager relay device; show the first crack in Zoë’s disbelief.

[[C01-LQQ43KHU2K]] Mood shift; set up rooftop motif.

[[C01-EI6DZKHLSQ]] Slow the moment to heighten mood; show compulsive behaviour building before the next signal return.

[[C01-UX62GAOZDY]] Escalate the mystery.

[[C01-C5TD22IQZO]] Act I turn: confirm temporal weirdness.

[[C01-WUAX2RUPPY]] Humanise; hint at consequence.

[[C01-EOGTEJ73EG]] Commitment and secrecy pact.

[[C01-PC3C53MT6F]] Seed motif early; make it feel like a joke that will become a verdict.
