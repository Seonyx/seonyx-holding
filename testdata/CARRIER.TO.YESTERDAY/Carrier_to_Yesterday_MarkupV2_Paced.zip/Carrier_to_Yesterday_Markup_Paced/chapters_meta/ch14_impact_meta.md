# Chapter 14 Meta Notes - Impact

## What this file is
Keyed meta notes aligned 1:1 with the chapter text paragraphs.

## Meta entries

[[C14-QVXZ45PH7P]] POV fragmented; aftermath.

[[C14-XPDIZGDDMT]] Emotional weight.

[[C14-PFYLBJIHNE]] Plot: evidence and futility.

[[C14-V2VH3MXYMY]] History shift as trauma.

[[C14-JWIMWDOXV5]] Mentor returns.

[[C14-4GTSIVGNE2]] Tragic beat.

[[C14-UNZQTTPE34]] Theme: system self-protection.

[[C14-5KQMJYUZ3J]] Consequence.

[[C14-YXA7EZBFUK]] Isolation.

[[C14-WR6J5BGLD5]] Theme.

[[C14-2R3PI3B2B3]] Dread.

[[C14-CC3JTFPPCY]] Reality instability.

[[C14-6ZFSZDA3QU]] Antagonist resolution.

[[C14-QPTF4H6L6C]] Justify meta system. + Loop persists. + Irony; loop closure.
