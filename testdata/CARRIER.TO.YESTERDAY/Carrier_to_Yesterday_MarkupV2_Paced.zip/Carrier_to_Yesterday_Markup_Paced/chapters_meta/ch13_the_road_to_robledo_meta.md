# Chapter 13 Meta Notes - The Road to Robledo

## What this file is
Keyed meta notes aligned 1:1 with the chapter text paragraphs.

## Meta entries

[[C13-POCA3LOMP6]] Set crash mechanics; POV.

[[C13-FMCYJBAGUP]] Tragic flaw.

[[C13-5NFF7UWXOD]] Signal/road merge.

[[C13-RLKP5I34KX]] Cause-and-effect setup.

[[C13-Y7L7BRSHGY]] Antagonist patience.

[[C13-7JSASGYG7A]] Pressure.

[[C13-DZ2JAVWUA6]] Atmosphere and danger.

[[C13-RQF6YAIU5B]] Motif returns in distorted form.

[[C13-6TDZ2M57IG]] Human moment leading to disaster.

[[C13-3MNWKRGECH]] Ironic realism.

[[C13-XFIU7RM4W6]] Sensory action.

[[C13-YD5YG7DQ7S]] Theme crystallises.

[[C13-WQ2D3XDWQC]] Crash beat.

[[C13-LMH2IPMMVC]] Aftermath; antagonist as witness. + Consequences. + Lead into aftermath chapter.
