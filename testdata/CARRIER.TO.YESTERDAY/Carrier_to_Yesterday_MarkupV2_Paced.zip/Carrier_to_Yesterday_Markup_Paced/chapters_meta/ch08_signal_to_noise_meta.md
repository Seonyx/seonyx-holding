# Chapter 08 Meta Notes - Signal-to-Noise

## What this file is
Keyed meta notes aligned 1:1 with the chapter text paragraphs.

## Meta entries

[[C08-HLJD247AYQ]] Trust fracture.

[[C08-MO4LGHW2ED]] Signal-to-noise theme literalised.

[[C08-LY6D72SUC2]] Metaphysical escalation.

[[C08-TZ6GREYDEQ]] Science vs. experience.

[[C08-SXKDOIVYIG]] Heist pressure.

[[C08-LDZD4HF7DL]] Urgency and greed.

[[C08-AE5FQ5QUA7]] Relationship tension.

[[C08-ZBHARBQRWE]] Temptation; ambiguity.

[[C08-L2LVPWOTXU]] Imply others have idea; paranoia.

[[C08-DMMFNNL4LD]] Introduce corruption; consequences.

[[C08-TIZWE3PYWI]] Theme: system self-protection.

[[C08-EC4AHU3ADN]] Character evolution.

[[C08-YEXFZCCF2M]] Mentor; observer effect.

[[C08-AK6C2OSNJW]] Opposing goals.

[[C08-NF67GFYOUP]] Act II turn toward climax. + Personalisation; dread spike.
