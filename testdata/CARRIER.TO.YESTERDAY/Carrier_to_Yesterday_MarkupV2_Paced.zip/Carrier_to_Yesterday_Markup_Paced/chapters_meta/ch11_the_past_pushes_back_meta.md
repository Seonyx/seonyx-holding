# Chapter 11 Meta Notes - The Past Pushes Back

## What this file is
Keyed meta notes aligned 1:1 with the chapter text paragraphs.

## Meta entries

[[C11-ATGXM5DJR5]] Tragic flaw in action.

[[C11-4RZ5FHFOLP]] Technical problem-solving; irony.

[[C11-YBFEL4VXDZ]] Conflict.

[[C11-TITL2XZGUP]] Escalate stakes.

[[C11-4H4TDGWHJ7]] Squeeze from another side.

[[C11-EHEMNZVAPE]] Clever but doomed plan.

[[C11-2BHLM76MT5]] Human error setup.

[[C11-LUQ4VBGIJT]] Closed loop irony.

[[C11-ZWTH2Q3RKO]] Horror.

[[C11-H5STQYLJPU]] Hubris.

[[C11-WKKFP3S5MN]] Compression into climax.

[[C11-WCTZGHD4Y5]] Thriller energy.

[[C11-D44QBJ36YR]] Character tragedy.

[[C11-JHQPHSJYAB]] Theme statement.

[[C11-YTETMOSK7C]] Fatal attachment.

[[C11-7BXKQ6YVQ2]] Act II closes into Act III.
