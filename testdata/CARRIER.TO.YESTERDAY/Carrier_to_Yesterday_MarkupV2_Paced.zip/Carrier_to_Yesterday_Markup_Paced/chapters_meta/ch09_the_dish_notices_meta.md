# Chapter 09 Meta Notes - The Dish Notices

## What this file is
Keyed meta notes aligned 1:1 with the chapter text paragraphs.

## Meta entries

[[C09-W33PJOCMFA]] Paranoia, personal stakes.

[[C09-BPFSIPHTZK]] External threat crystallises.

[[C09-UMEEHK47HM]] Heist montage.

[[C09-VRCNWOP2MJ]] Zoë’s agency; boundary.

[[C09-AE4LP4C2WO]] Secret goal.

[[C09-5HIJE5TEBP]] Antagonist proximity.

[[C09-APRMRNMNZS]] Tension.

[[C09-7RD4OGPILD]] Antagonist presence.

[[C09-LSHVMTIJ5Y]] Fatalism mood.

[[C09-YWWYYV4APF]] Hubris.

[[C09-7EDAVD23QA]] History shift continues.

[[C09-YPLNZM7YFW]] Action beat.

[[C09-EQWAYKPFNZ]] Stakes spike.

[[C09-Y4AGLD65GG]] Chase energy. + Relationship rupture. + Threat set for next chapter.
